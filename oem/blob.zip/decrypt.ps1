# decrypt.ps1

# Parameters
$PasswordFile = "secret"
$CipherFile = "blob"
$HmacFile = "blob.hmac"

$ClearFile = "srcfiles.zip"

$Iter = 2000000
$HmacKeyFile = "hmac.key"

# Extract Salt
$salt = [System.IO.File]::ReadAllBytes($CipherFile)[8..15]
$HexSalt = ($salt | ForEach-Object { $_.ToString("x2") }) -join ""

# Derive HMAC key
& openssl kdf -keylen 32 -binary    `
    -out $HmacKeyFile               `
    -kdfopt digest:SHA256           `
    -kdfopt pass:file:$PasswordFile `
    -kdfopt hexsalt:$HexSalt        `
    -kdfopt iter:$Iter PBKDF2
$HmacHexKey = -join ((Get-Content $HmacKeyFile -Encoding Byte) | ForEach-Object { $_.ToString("x2") })

# Verify HMAC before decrypting
$VerifyResult = & openssl dgst -sha256 -mac HMAC -macopt hexkey:$HmacHexKey $CipherFile
$ExpectedHmac = Get-Content $HmacFile | ForEach-Object { $_.Trim() }

if ($VerifyResult.Trim() -eq $ExpectedHmac.Trim()) {
    Write-Host "`n[+] HMAC matches, proceeding to decrypt."
    & openssl enc -d -aes-256-cbc -pbkdf2 `
        -iter $Iter                       `
        -in $CipherFile                   `
        -out $ClearFile                   `
        -pass file:$PasswordFile
    Write-Host "`n[+] Decryption completed."
} else {
    Write-Host "`n[-] ERROR: HMAC does not match. Decryption aborted."
}

