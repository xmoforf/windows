# decrypt.ps1

# Parameters
$PasswordFile = "secret"
$HexSaltFile = "salt.hex"
$CipherFile = "blob"
$HmacFile = "blob.hmac"

$ClearFile = "srcfiles.zip"

$Iter = 100000
$Password = Get-Content $PasswordFile -Raw
$HexSalt =  Get-Content $HexSaltFile  -Raw
$HmacKeyFile = "hmac.key"

# Derive HMAC key
& openssl kdf -keylen 32 -binary    `
    -out $HmacKeyFile               `
    -kdfopt digest:SHA256           `
    -kdfopt pass:file:$PasswordFile `
    -kdfopt hexsalt:$HexSalt        `
    -kdfopt iter:$Iter PBKDF2
$HmacHexKey = -join ((Get-Content $HmacKeyFile -Encoding Byte) | ForEach-Object { $_.ToString("x2") })

# Verify HMAC before decrypting
$VerifyResult = & openssl dgst -sha256 -mac HMAC -macopt hexkey:$HmacHexKey $CipherFile
$ExpectedHmac = Get-Content $HmacFile | ForEach-Object { $_.Trim() }

if ($VerifyResult.Trim() -eq $ExpectedHmac.Trim()) {
    Write-Host "`n[+] HMAC matches, proceeding to decrypt."
    & openssl enc -d -aes-256-cbc -pbkdf2 `
        -salt -S $HexSalt -iter $Iter `
        -in $CipherFile `
        -out $ClearFile `
        -pass file:$PasswordFile
    Write-Host "`n[+] Decryption completed."
} else {
    Write-Host "`n[-] ERROR: HMAC does not match. Decryption aborted."
}

